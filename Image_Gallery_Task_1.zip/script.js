let images = document.querySelectorAll(".gallery img");
let current = 0;

function openLightbox(src) {
    document.getElementById("lightbox").style.display = "flex";

    images.forEach((img, index) => {
        if (img.src === src) {
            current = index;
        }
    });

    document.getElementById("lightbox-img").src = src;
}

function closeLightbox() {
    document.getElementById("lightbox").style.display = "none";
}

function changeImage(direction) {
    current += direction;

    if (current < 0) {
        current = images.length - 1;
    }

    if (current >= images.length) {
        current = 0;
    }

    document.getElementById("lightbox-img").src = images[current].src;
}

function filterImages(category) {
    let items = document.querySelectorAll(".image");

    items.forEach(item => {
        if (category === "all" || item.classList.contains(category)) {
            item.style.display = "block";
        } else {
            item.style.display = "none";
        }
    });
}

document.getElementById("lightbox").addEventListener("click", function(event) {
    if (event.target.id === "lightbox") {
        closeLightbox();
    }
});

document.addEventListener("keydown", function(event) {
    if (event.key === "Escape") {
        closeLightbox();
    } else if (event.key === "ArrowLeft") {
        changeImage(-1);
    } else if (event.key === "ArrowRight") {
        changeImage(1);
    }
});
